/* Kaizen Barbearia — front-end (JS puro, sem dependências) */
(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const fine = matchMedia('(hover:hover) and (pointer:fine)').matches;
const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
const icon = (id) => `<svg class="ico" aria-hidden="true"><use href="#i-${id}"/></svg>`;
const money = (n) => 'R$ ' + (Number.isInteger(n) ? n : n.toFixed(2).replace('.', ','));
const pad = (n) => String(n).padStart(2, '0');

/* ---------- configuração padrão (usada se o servidor não responder) ---------- */
const DEMO = {
  business: { name: 'Kaizen Barbearia', whatsapp: '', instagram: '', phone: '', address: '', mapsUrl: '' },
  services: [
    { id: 'corte', name: 'Corte masculino', desc: 'Corte moderno, social ou na máquina. Do seu jeito.', price: 35, duration: 40, icon: 'scissors', image: 'img/service1.jpg' },
    { id: 'barba', name: 'Barba na navalha', desc: 'Barba bem feita, com acabamento profissional e toalha quente.', price: 25, duration: 30, icon: 'beard', image: 'img/service2.jpg' },
    { id: 'combo', name: 'Combo corte + barba', desc: 'O combo completo para um visual impecável.', price: 55, duration: 70, icon: 'chair', image: 'img/service3.jpg' }
  ],
  hours: { 0: null, 1: ['09:00', '19:00'], 2: ['09:00', '19:00'], 3: ['09:00', '19:00'], 4: ['09:00', '19:00'], 5: ['09:00', '19:00'], 6: ['09:00', '17:00'] },
  step: 30, daysAhead: 14
};
let CFG = null, demo = false;

const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const toMin = (t) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const toHH = (m) => `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
function demoDays() {
  const out = [], base = new Date(); base.setHours(12, 0, 0, 0);
  for (let i = 0; i <= DEMO.daysAhead; i++) { const d = new Date(base); d.setDate(d.getDate() + i); out.push({ date: iso(d), open: !!DEMO.hours[d.getDay()] }); }
  return out;
}
const store = { get: () => { try { return JSON.parse(localStorage.getItem('kz-demo-bookings') || '[]'); } catch (_) { return []; } }, set: (v) => { try { localStorage.setItem('kz-demo-bookings', JSON.stringify(v)); } catch (_) {} } };
function demoSlots(date, svc) {
  const d = new Date(date + 'T12:00:00'), h = DEMO.hours[d.getDay()]; if (!h) return [];
  const now = new Date(), isToday = iso(now) === date, nowMin = now.getHours() * 60 + now.getMinutes() + 30;
  const busy = store.get().filter((b) => b.date === date);
  const out = [];
  for (let t = toMin(h[0]); t + svc.duration <= toMin(h[1]); t += DEMO.step) {
    if (isToday && t < nowMin) continue;
    if (busy.some((b) => t < b.end && t + svc.duration > b.start)) continue;
    out.push(toHH(t));
  }
  return out;
}

async function loadConfig() {
  try {
    const r = await fetch('api/config', { headers: { Accept: 'application/json' } });
    if (!r.ok || !(r.headers.get('content-type') || '').includes('json')) throw 0;
    const j = await r.json(); if (!j.ok) throw 0;
    CFG = j; demo = false;
  } catch (_) {
    CFG = { business: DEMO.business, services: DEMO.services, days: demoDays() }; demo = true;
  }
}

/* ---------- renderização ---------- */
function renderServices() {
  const box = $('#svc'); box.innerHTML = '';
  CFG.services.forEach((s, i) => {
    const a = el('a', 'card rv'); a.href = '#agendar'; a.dataset.service = s.id; a.style.setProperty('--d', i * 110 + 'ms');
    a.setAttribute('aria-label', `${s.name}, a partir de ${money(s.price)}. Agendar`);
    a.innerHTML = `<span class="ph"><img src="${s.image}" alt="" loading="lazy" decoding="async"></span>
      <span class="bd"><span class="badge">${icon(s.icon)}</span>
      <span class="tx"><h3>${s.name}</h3><p>${s.desc}</p></span>
      <span class="price"><span><small>A partir de</small><strong>${money(s.price)}</strong></span>${icon('r').replace('class="ico"', 'class="ico go"')}</span>
      <span class="chev-col">${icon('r')}</span></span>`;
    box.appendChild(a);
  });
}
const GAL = [
  { src: 'img/hero.jpg', ox: '58%', oy: '52%', z: 1.9, t: 'Precisão', tall: true },
  { src: 'img/hero.jpg', ox: '83%', oy: '18%', z: 2.3, t: 'Nossa marca' },
  { src: 'img/service1.jpg', ox: '50%', oy: '40%', z: 1, t: 'Degradê' },
  { src: 'img/service2.jpg', ox: '60%', oy: '50%', z: 1, t: 'Navalha', tall: true },
  { src: 'img/hero.jpg', ox: '90%', oy: '60%', z: 1.8, t: 'Acabamento' },
  { src: 'img/service3.jpg', ox: '45%', oy: '45%', z: 1, t: 'Relax' }
];
function renderGallery() {
  const g = $('#grid'); g.innerHTML = '';
  GAL.forEach((p, i) => {
    const b = el('button', 'tile rv' + (p.tall ? ' tall' : '')); b.type = 'button'; b.style.setProperty('--d', (i % 4) * 90 + 'ms');
    b.style.setProperty('--ox', p.ox); b.style.setProperty('--oy', p.oy); b.style.setProperty('--z', p.z);
    b.setAttribute('aria-label', `Ampliar foto: ${p.t}`);
    b.innerHTML = `<img src="${p.src}" alt="" loading="lazy" decoding="async"><span>${p.t}</span>`;
    b.addEventListener('click', () => { const lb = $('#lb'), im = $('#lbi'); im.src = p.src; im.alt = p.t; ['ox', 'oy', 'z'].forEach((k) => lb.style.setProperty('--' + k, p[k])); lb.showModal(); document.documentElement.classList.add('lock'); });
    g.appendChild(b);
  });
}
function renderContact() {
  const b = CFG.business, box = $('#ct'); box.innerHTML = '';
  const wa = String(b.whatsapp || '').replace(/\D/g, '');
  const add = (tag, href, ic, title, sub) => { const n = el(tag, 'ct-item rv'); if (href) { n.href = href; if (/^https?:/.test(href)) { n.target = '_blank'; n.rel = 'noopener'; } } n.innerHTML = `<span class="badge">${icon(ic)}</span><span><b>${title}</b><small>${sub}</small></span>`; box.appendChild(n); return n; };
  if (wa) add('a', `https://wa.me/${wa}`, 'wa', 'WhatsApp', 'Fale direto com a barbearia');
  if (b.instagram) add('a', b.instagram.startsWith('http') ? b.instagram : `https://instagram.com/${b.instagram.replace('@', '')}`, 'ig', 'Instagram', 'Siga nosso trabalho');
  if (b.phone) add('a', `tel:${b.phone.replace(/[^\d+]/g, '')}`, 'phone', 'Telefone', b.phone);
  if (b.address) add('a', b.mapsUrl || `https://maps.google.com/?q=${encodeURIComponent(b.address)}`, 'pin', 'Endereço', b.address);
  const n = add('button', null, 'scissors', 'Agendamento online', 'Escolha serviço, dia e horário'); n.type = 'button'; n.dataset.book = '';
  if (box.children.length % 2 === 1) { const l = box.lastElementChild; l.style.gridColumn = '1/-1'; if (box.children.length === 1) { l.style.maxWidth = '420px'; l.style.margin = '0 auto'; } }
}

/* ---------- animações / interações gerais ---------- */
function reveal() {
  const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .12, rootMargin: '0px 0px -6% 0px' });
  $$('.rv').forEach((n) => io.observe(n));
}
function tilt() {
  if (!fine || reduce) return;
  $$('.card').forEach((c) => {
    c.addEventListener('pointermove', (e) => { const r = c.getBoundingClientRect(); c.style.setProperty('--ry', (((e.clientX - r.left) / r.width - .5) * 3.4).toFixed(2) + 'deg'); c.style.setProperty('--rx', (-((e.clientY - r.top) / r.height - .5) * 3.4).toFixed(2) + 'deg'); });
    c.addEventListener('pointerleave', () => { c.style.setProperty('--rx', '0deg'); c.style.setProperty('--ry', '0deg'); });
  });
}
document.addEventListener('pointerdown', (e) => {   // ondinha no botão
  const b = e.target.closest('.btn'); if (!b || reduce) return;
  const r = b.getBoundingClientRect(), s = Math.max(r.width, r.height), p = el('span', 'rip');
  p.style.cssText = `width:${s}px;height:${s}px;left:${e.clientX - r.left - s / 2}px;top:${e.clientY - r.top - s / 2}px`;
  b.appendChild(p); setTimeout(() => p.remove(), 650);
});
function header() {
  const h = $('#hdr'); const f = () => h.classList.toggle('solid', scrollY > 24); f(); addEventListener('scroll', f, { passive: true });
  const burger = $('#burger'), dr = $('#drawer');
  const set = (o) => { dr.classList.toggle('open', o); burger.setAttribute('aria-expanded', o); dr.setAttribute('aria-hidden', !o); document.documentElement.classList.toggle('lock', o); };
  burger.addEventListener('click', () => set(!dr.classList.contains('open')));
  $$('a.lnk', dr).forEach((a) => a.addEventListener('click', () => set(false)));
  $('[data-book]', dr).addEventListener('click', () => set(false));
  addEventListener('keydown', (e) => { if (e.key === 'Escape') set(false); });
  addEventListener('resize', () => { if (innerWidth >= 900) set(false); });
  // seção ativa
  const secs = ['inicio', 'servicos', 'galeria', 'contato'].map((id) => document.getElementById(id));
  const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) $$('[data-nav]').forEach((a) => { const on = a.dataset.nav === e.target.id; a.classList.toggle('on', on); on ? a.setAttribute('aria-current', 'true') : a.removeAttribute('aria-current'); }); }), { rootMargin: '-45% 0px -50% 0px' });
  secs.forEach((s) => io.observe(s));
}
function heroFx() {
  const hero = $('#inicio'), img = $('#heroImg');
  requestAnimationFrame(() => { hero.classList.add('go-in'); });
  if (fine && !reduce) hero.addEventListener('pointermove', (e) => { const r = hero.getBoundingClientRect(); img.style.setProperty('--px', (-((e.clientX - r.left) / r.width - .5) * 22).toFixed(1) + 'px'); img.style.setProperty('--py', (-((e.clientY - r.top) / r.height - .5) * 12).toFixed(1) + 'px'); });
  embers(hero);
}

/* ---------- canvas: brasas douradas ---------- */
function embers(hero) {
  const cv = $('#embers'), ctx = cv.getContext('2d'); if (!ctx || reduce) return;
  let w = 0, h = 0, dpr = 1, P = [], run = false, raf = 0, last = 0, vis = true;
  const rnd = (a, b) => a + Math.random() * (b - a);
  const spawn = (init) => ({ x: rnd(0, w), y: init ? rnd(0, h) : h + 10, r: rnd(.6, 2.2), v: rnd(10, 34), dr: rnd(-8, 8), ph: rnd(0, 6.28), fl: rnd(.8, 2.4), a: rnd(.25, .85) });
  function size() { dpr = Math.min(2, devicePixelRatio || 1); w = hero.clientWidth; h = hero.clientHeight; cv.width = w * dpr; cv.height = h * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); const n = Math.round(Math.min(46, w / 14)); P = Array.from({ length: n }, () => spawn(true)); }
  function draw(t) {
    if (!run) return; const dt = Math.min(.05, (t - last) / 1000 || .016); last = t;
    ctx.clearRect(0, 0, w, h); ctx.globalCompositeOperation = 'lighter';
    for (const p of P) {
      p.y -= p.v * dt; p.x += (p.dr + Math.sin(t / 1000 * p.fl + p.ph) * 9) * dt;
      if (p.y < -10 || p.x < -10 || p.x > w + 10) Object.assign(p, spawn(false));
      const fade = Math.min(1, p.y / (h * .35), (h - p.y) / 40), a = p.a * (.55 + .45 * Math.sin(t / 1000 * p.fl * 2 + p.ph)) * Math.max(0, Math.min(1, fade));
      const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 5);
      g.addColorStop(0, `rgba(255,190,120,${a})`); g.addColorStop(.35, `rgba(240,140,80,${a * .35})`); g.addColorStop(1, 'rgba(224,122,87,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 5, 0, 6.283); ctx.fill();
    }
    raf = requestAnimationFrame(draw);
  }
  const start = () => { if (run || !vis || document.hidden) return; run = true; last = performance.now(); raf = requestAnimationFrame(draw); };
  const stop = () => { run = false; cancelAnimationFrame(raf); };
  size(); addEventListener('resize', size);
  new IntersectionObserver((es) => { vis = es[0].isIntersecting; vis ? start() : stop(); }).observe(hero);
  document.addEventListener('visibilitychange', () => document.hidden ? stop() : start());
  start();
}

/* ---------- agendamento ---------- */
const dlg = $('#book'), form = $('#bf');
const S = { svc: null, date: null, time: null, busy: false };
const weekday = (d) => new Date(d + 'T12:00:00').toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', '').toUpperCase();
const longDate = (d) => new Date(d + 'T12:00:00').toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' });

function radio(btn, group) { $$('[role=radio]', group).forEach((b) => b.setAttribute('aria-checked', b === btn)); }
function buildBooking(preId) {
  S.svc = null; S.date = null; S.time = null;
  $('#err').textContent = ''; $('#demo').hidden = !demo;
  const opts = $('#opts'); opts.innerHTML = '';
  CFG.services.forEach((s) => {
    const b = el('button', 'opt'); b.type = 'button'; b.setAttribute('role', 'radio'); b.setAttribute('aria-checked', 'false'); b.dataset.id = s.id;
    b.innerHTML = `<span><b>${s.name}</b><small>${s.duration} min</small></span><span class="p">${money(s.price)}</span>`;
    b.addEventListener('click', () => { S.svc = s; radio(b, opts); S.time = null; loadTimes(); });
    opts.appendChild(b);
  });
  const days = $('#days'); days.innerHTML = '';
  CFG.days.forEach((d) => {
    const b = el('button', 'day'); b.type = 'button'; b.setAttribute('role', 'radio'); b.setAttribute('aria-checked', 'false'); b.disabled = !d.open; b.dataset.date = d.date;
    b.setAttribute('aria-label', d.open ? longDate(d.date) : longDate(d.date) + ' (fechado)');
    b.innerHTML = `${weekday(d.date)}<strong>${d.date.slice(8)}</strong>`;
    b.addEventListener('click', () => { S.date = d.date; radio(b, days); S.time = null; loadTimes(); });
    days.appendChild(b);
  });
  $('#times').innerHTML = '<p class="hint">Escolha o serviço e o dia.</p>';
  if (preId) { const b = $(`.opt[data-id="${preId}"]`, opts); if (b) b.click(); }
  const first = $('.day:not(:disabled)', days); if (first && preId) first.click();
}
async function loadTimes() {
  const box = $('#times'); S.time = null;
  if (!S.svc || !S.date) { box.innerHTML = '<p class="hint">Escolha o serviço e o dia.</p>'; return; }
  box.innerHTML = '<p class="hint">Buscando horários…</p>';
  let slots = [];
  try {
    if (demo) slots = demoSlots(S.date, S.svc);
    else { const r = await fetch(`api/slots?date=${S.date}&service=${S.svc.id}`); const j = await r.json(); if (!j.ok) throw 0; slots = j.slots; }
  } catch (_) { box.innerHTML = '<p class="hint">Não foi possível carregar os horários. Tente novamente.</p>'; return; }
  if (!slots.length) { box.innerHTML = '<p class="hint">Sem horários livres nesse dia. Escolha outro dia.</p>'; return; }
  const g = el('div', 'times'); slots.forEach((t) => { const b = el('button', 'time', t); b.type = 'button'; b.setAttribute('role', 'radio'); b.setAttribute('aria-checked', 'false'); b.addEventListener('click', () => { S.time = t; radio(b, g); $('#err').textContent = ''; }); g.appendChild(b); });
  box.innerHTML = ''; box.appendChild(g);
}
function openBooking(preId) {
  if (!CFG) return;
  $('#ok').hidden = true; form.hidden = false; buildBooking(preId);
  dlg.showModal(); document.documentElement.classList.add('lock');
}
function closeAll() { [dlg, $('#lb')].forEach((d) => d.open && d.close()); }
['book', 'lb'].forEach((id) => { const d = document.getElementById(id); d.addEventListener('close', () => document.documentElement.classList.remove('lock')); d.addEventListener('click', (e) => { if (e.target === d) d.close(); }); });
$('#bx').addEventListener('click', closeAll); $('#okx').addEventListener('click', closeAll); $('#lbx').addEventListener('click', closeAll);
document.addEventListener('click', (e) => {
  const c = e.target.closest('.card'); if (c) { e.preventDefault(); openBooking(c.dataset.service); return; }
  if (e.target.closest('[data-book]')) { e.preventDefault(); openBooking(); }
});
$('#fp').addEventListener('input', (e) => {   // máscara (11) 99999-9999
  let v = e.target.value.replace(/\D/g, '').slice(0, 11);
  if (v.length > 6) v = `(${v.slice(0, 2)}) ${v.slice(2, v.length > 10 ? 7 : 6)}-${v.slice(v.length > 10 ? 7 : 6)}`; else if (v.length > 2) v = `(${v.slice(0, 2)}) ${v.slice(2)}`;
  e.target.value = v;
});
form.addEventListener('submit', async (e) => {
  e.preventDefault(); if (S.busy) return;
  const err = $('#err'), name = $('#fn').value.trim(), phone = $('#fp').value.replace(/\D/g, '');
  if (!S.svc) return err.textContent = 'Escolha o serviço.';
  if (!S.date) return err.textContent = 'Escolha o dia.';
  if (!S.time) return err.textContent = 'Escolha o horário.';
  if (name.length < 2) { $('#fn').focus(); return err.textContent = 'Informe seu nome.'; }
  if (phone.length < 10) { $('#fp').focus(); return err.textContent = 'Informe seu WhatsApp com DDD.'; }
  err.textContent = ''; S.busy = true; const btn = $('#sub'); btn.disabled = true; btn.style.opacity = .7; btn.firstChild.textContent = 'Enviando…';
  try {
    let res;
    if (demo) {
      const b = store.get(), start = toMin(S.time);
      if (b.some((x) => x.date === S.date && start < x.end && start + S.svc.duration > x.start)) throw new Error('Esse horário acabou de ser reservado. Escolha outro.');
      b.push({ date: S.date, start, end: start + S.svc.duration }); store.set(b);
      res = { booking: { service: S.svc.name, price: S.svc.price, date: S.date, time: S.time, name }, whatsappUrl: null };
    } else {
      const r = await fetch('api/bookings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ serviceId: S.svc.id, date: S.date, time: S.time, name, phone, website: $('#fw').value }) });
      const j = await r.json().catch(() => ({})); if (!r.ok || !j.ok) { if (r.status === 409) loadTimes(); throw new Error(j.error || 'Não foi possível agendar. Tente novamente.'); }
      res = j;
    }
    showOk(res);
  } catch (ex) { err.textContent = ex.message || 'Erro ao agendar.'; }
  finally { S.busy = false; btn.disabled = false; btn.style.opacity = 1; btn.firstChild.textContent = 'Confirmar agendamento'; }
});
function showOk(res) {
  const b = res.booking; form.hidden = true; $('#ok').hidden = false;
  $('#okmsg').textContent = demo ? 'Reserva de demonstração salva neste navegador.' : `Obrigado, ${b.name.split(' ')[0]}! Te esperamos na Kaizen.`;
  $('#sum').innerHTML = `<div><span>Serviço</span><b>${b.service}</b></div><div><span>Data</span><b>${longDate(b.date)}</b></div><div><span>Horário</span><b>${b.time}</b></div><div><span>Valor</span><b>${money(b.price)}</b></div>`;
  const wa = $('#wa'); if (res.whatsappUrl) { wa.href = res.whatsappUrl; wa.hidden = false; } else wa.hidden = true;
  $('.sheet').scrollTop = 0;
}

/* ---------- início ---------- */
(async () => {
  $('#yr').textContent = new Date().getFullYear();
  header(); heroFx();
  await loadConfig();
  renderServices(); renderGallery(); renderContact();
  reveal(); tilt();
})();
})();
